<?php
    $URL = 'http://94.183.244.62:8098/crm/WebService/w.php';

    $client = new SoapClient(null, array(
        'location' => $URL,
        'uri'      => "http://94.183.244.62:8098/crm/WebService/",
        'trace'    => 1,
    ));
    $response = $client->__soapCall("getFactors", array());
    $result = json_decode($response);
    var_dump($result);
